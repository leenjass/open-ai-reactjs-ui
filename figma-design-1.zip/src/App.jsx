import { useState } from 'react'
import './App.css'
import { Blog, Feature, Header, Possibility, Whatgpt3, Footer } from './containers';
import {Brand, Navbar, CTA} from './components';
function App() {

  return (
    <>
      <div className='gradient_header'>
        <Navbar />
        <Header />
      </div>
      <Brand />
      <Whatgpt3 />
      <Feature />
      <Possibility />
      <CTA />
      <Blog />
      <Footer />
    </>
  )
}

export default App
