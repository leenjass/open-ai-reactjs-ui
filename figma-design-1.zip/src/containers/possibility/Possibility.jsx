import React from "react";
import './possibility.css';

export const Possibility = () => {
    return(
        <div>
            <h1>Possibility</h1>
        </div>
    );

};