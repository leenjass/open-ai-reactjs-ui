import React from "react";
import './footer.css';

export const Footer = () => {
    return(
        <div>
            <h1>Footer</h1>
        </div>
    );

};