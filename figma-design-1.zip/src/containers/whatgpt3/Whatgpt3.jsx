import React from "react";
import './whatgpt3.css';

export const Whatgpt3 = () => {
    return(
        <div>
            <h1>Whatgpt3</h1>
        </div>
    );

};