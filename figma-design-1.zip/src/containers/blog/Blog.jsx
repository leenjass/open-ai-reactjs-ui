import React from "react";
import './blog.css';

export const Blog = () => {
    return(
        <div>
            <h1>Blog</h1>
        </div>
    );

};