import React from "react";
import './brand.css';

export const Brand = () => {
    return(
        <div>
            <h1>Brand</h1>
        </div>
    );

};