import React from "react";
import './cta.css';

export const CTA = () => {
    return(
        <div>
            <h1>CTA</h1>
        </div>
    );

};