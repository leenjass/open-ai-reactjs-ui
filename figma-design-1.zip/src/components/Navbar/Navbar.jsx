import React from "react";
import './navbar.css';
import logo from '../../assets/logo.svg';

export const Navbar = () => {
    return(
        <div className="navigation_main container">
            <div className="left_section">
                <div className="log_section">
                    <img src={logo} alt="" />
                </div>
                <div className="navigation_section">
                    <a href="#">Home</a>
                    <a href="#">What is GPT?</a>
                    <a href="#">Open AI</a>
                    <a href="#">Case Studies</a>
                    <a href="#">Library</a>
                </div>
            </div>
            <div className="right_section">
                <a href="#">Sign in</a>
                <button>Sign up</button>
            </div>

        </div>
    );

};