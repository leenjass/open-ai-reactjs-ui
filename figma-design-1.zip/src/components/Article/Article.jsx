import React from "react";
import './article.css';

export const Article = () => {
    return(
        <div>
            <h1>Article</h1>
        </div>
    );

};