import React from "react";
import './feature.css';

export const Feature = () => {
    return(
        <div>
            <h1>Feature</h1>
        </div>
    );

};